#pragma once
#include <vector>
#include <SFML/Graphics.hpp>
#include <iostream>
#include "textureManager.h"
#include "Random.h"
using namespace sf;
using namespace std;

class board{

public:
    bool won = false;
    bool lost = false;
    bool gameOver = false;
    bool debugMode = false;
    int numRows;
    int numCol;
    void sideTileCheck();
    int numMines;
    int numTiles;
    int flagCounter = 0;
    class Tiles{
        bool isNum;
        bool isNothing;
    public:
        vector<Tiles> adjecentTiles;
        bool isMine;
        bool isReveal;
        bool isFlag;
        int mineCount = 0;
        Sprite Tile;
        Tiles(bool setMine){
            isMine = setMine;
            isNum = false;
            isNothing = false;
            isReveal = false;
            isFlag = false;
            Tile.setTexture(textureManager::getTexture("tile_hidden"));
        };
        void makeMine(bool isMine){
            this->isMine = isMine;
        };
    };
    void recursion(int i, int j);
    void resetBoard(string file,  map<string, board>& boards);
    void read(string filename);
    void gameCheck();
    void gameEnd();
    void remainingMines(sf::RenderWindow& window, int width, int height);
    board(){
        this->numMines = 0;
        this->numRows = 0;
        this->numCol = 0;
        this->numTiles = 0;
    };
    board(int numMines, int numRows, int numCol, int numTiles){
        this->numMines = numMines;
        this->numRows = numRows;
        this->numCol = numCol;
        this->numTiles = numTiles;
    }

    vector<vector<Tiles>> gameBoard;
    void getRandomMines();
};


void readIn(map<string, board>& boards);
void draw(RenderWindow& window, map<string, board>& boards);