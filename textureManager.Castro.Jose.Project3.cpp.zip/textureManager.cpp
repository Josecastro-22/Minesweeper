#include "textureManager.h"
map<string, Texture> textureManager::textures;
// this is reading images and storing them from image folder
void textureManager::loadTexture(string file){
    string imagesFolder = "images/";
    imagesFolder += file + ".png";
    textures[file].loadFromFile(imagesFolder);

}
Texture& textureManager::getTexture(string file){
    //try and find the texture and see if its loaded and if not it will load it
    if (textures.find(file) == textures.end()){
        loadTexture(file);

    }
    return textures[file];

}


