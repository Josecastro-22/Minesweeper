#include <fstream>
#include "Board.h"
#include <string>
using namespace std;
void board::getRandomMines(){
    int actualMine = 0;
    while(actualMine != numMines){
        int randomX = Random::number(0, numCol-1);
        int randomY = Random::number(0, numRows-1);
        if(!gameBoard[randomY][randomX].isMine){
            actualMine++;
            gameBoard[randomY][randomX].makeMine(true);
        }
    }
    sideTileCheck();
}
void board::remainingMines(sf::RenderWindow& window, int width, int height){
    int remainingMines =  numMines - flagCounter;
    int offset = 0;
    int one,ten,hundred;
    Sprite ones(textureManager::getTexture("digits"));
    ones.setPosition((float)21 * 3, (float)(height - 64));

    Sprite tens(textureManager::getTexture("digits"));
    tens.setPosition((float)21 * 2, (float)(height - 64));

    Sprite hundreds(textureManager::getTexture("digits"));
    hundreds.setPosition((float)21, (float)(height - 64));

    Sprite sign(textureManager::getTexture("digits"));
    sign.setPosition((float)0, (float)(height - 64));

    if(remainingMines < 0){
        sign.setTextureRect(Rect<int>(21 * 10, 0, 21, 32));
        window.draw(sign);
        remainingMines *= -1;
    }

    //154 mines
    //154 / 100 = 1
    //(154 % 100) / 10 = 5
    //154 % 10 = 4
    hundred = remainingMines / 100;
    ten = (remainingMines % 100) / 10;
    one  = remainingMines % 10;


    hundreds.setTextureRect(Rect<int>(21 * hundred, 0, 21, 32));
    window.draw(hundreds);
    tens.setTextureRect(Rect<int>(21 * ten, 0, 21, 32));
    window.draw(tens);
    ones.setTextureRect(Rect<int>(21 * one, 0, 21, 32));
    window.draw(ones);
}

void board::sideTileCheck(){
    for(int i = 0; i < numRows; i++){
        for(int j = 0; j < numCol; j++){
            int mineCount = 0;
            //up, left
            if ((i -1) >= 0 && (j - 1) >= 0 && gameBoard[i - 1][j - 1].isMine){
                mineCount++;

            }
            //up
            if((i -1) >= 0 &&gameBoard[i - 1][j].isMine){
                mineCount++;

            }
            //up,right
            if ((i -1) >= 0 && (j +1) < numCol && gameBoard[i - 1][j + 1].isMine){
                mineCount++;
            }
            //left
            if ((j - 1) >= 0 && gameBoard[i][j - 1].isMine){
                mineCount++;
            }
            //right
            if ((j + 1) < numCol && gameBoard[i][j + 1].isMine){
                mineCount++;
            }
            //down,left
            if ((i + 1) < numRows && (j - 1) >= 0 && gameBoard[i + 1][j - 1].isMine){
                mineCount++;
            }
            //down
            if ((i + 1) < numRows && gameBoard[i + 1][j].isMine){
                mineCount++;
            }
            //down, right
            if ((i + 1) < numRows && (j + 1) < numCol && gameBoard[i + 1][j + 1].isMine){
                mineCount++;
            }
            gameBoard[i][j].mineCount = mineCount;
        }
    }
}
void board::recursion(int i, int j){
    if ( !gameBoard[i][j].isFlag && !gameBoard[i][j].isMine && !gameBoard[i][j].isReveal){
        gameBoard[i][j].isReveal = true;
        if(gameBoard[i][j].mineCount == 0){
            if(j-1 >= 0){
                if(gameBoard[i][j-1].isReveal == false) {
                    recursion(i, j - 1);
                }
            }
            if(i -1 >=0 ){
                if(gameBoard[i-1][j].isReveal == false) {
                    recursion(i - 1, j);
                }
            }
            if(i -1 >= 0 && j -1 >=0){
                if(gameBoard[i-1][j-1].isReveal == false) {
                    recursion(i - 1, j - 1);
                }
            }
            if(i-1 >= 0 && j + 1 < numCol){
                if(gameBoard[i-1][j+1].isReveal == false) {
                    recursion(i - 1, j + 1);
                }
            }
            if(j +1 < numCol){
                if(gameBoard[i][j+1].isReveal == false) {
                    recursion(i, j + 1);
                }
            }
            if(i+1 < numRows){
                if(gameBoard[i+1][j].isReveal == false) {
                    recursion(i + 1, j);
                }
            }
            if(i+1 < numRows && j + 1 < numCol){
                if(gameBoard[i+1][j+1].isReveal == false) {
                    recursion(i + 1, j + 1);
                }
            }
            if(i+1 < numRows && j-1 >=0){
                if(gameBoard[i+1][j-1].isReveal == false) {
                    recursion(i + 1, j - 1);
                }
            }
        }
    }
}
void readIn(map<string, board>& boards) {
    cout << "opening" << endl;
    ifstream file("boards/config.cfg");
    cout << "open" << endl;
    int colNum, rowNum, minesNum;
    file >> colNum >> rowNum >> minesNum;
    cout << colNum << " " << rowNum << " " << minesNum<< endl;
    int width, height, middle, tileCount;
    width = colNum * 32;
    height = (rowNum * 32) + 100;
    middle = minesNum;
    tileCount = colNum * rowNum;
    board configBoard(middle, rowNum, colNum, tileCount);


    configBoard.gameBoard.resize(rowNum);
    for (int i = 0; i < rowNum; i++) {
        for (int j = 0; j < colNum; j++) {
            board::Tiles temp(false);
            temp.Tile.setPosition(32 * j, 32 * i);
            configBoard.gameBoard[i].push_back(temp);
        }
    }
    int actualMine = 0;
    for (int i = 0; i < rowNum; i++) {
        for (int j = 0; j < colNum; j++) {
            configBoard.gameBoard[i][j].Tile.setPosition(32 * j, 32 * i);
        }
    }
    boards["config"] = configBoard;
    boards["config"].getRandomMines();
    boards["config"].sideTileCheck();
    cout << "done" << endl;
}
void draw(RenderWindow& window, map<string, board>& boards) {
    for (int i = 0; i < boards["config"].gameBoard.size(); i++) {
        for (int j = 0; j < boards["config"].gameBoard[i].size(); j++) {
            window.draw(boards["config"].gameBoard[i][j].Tile);
            if(boards["config"].gameBoard[i][j].isReveal) {
                boards["config"].gameBoard[i][j].Tile.setTexture(textureManager::getTexture("tile_revealed"));
                window.draw(boards["config"].gameBoard[i][j].Tile);
                if(!boards["config"].gameBoard[i][j].isMine && boards["config"].gameBoard[i][j].mineCount > 0){
                    string num = "number_";
                    num += to_string(boards["config"].gameBoard[i][j].mineCount);
                    boards["config"].gameBoard[i][j].Tile.setTexture(textureManager::getTexture(num));
                    window.draw(boards["config"].gameBoard[i][j].Tile);
                }
                else if(boards["config"].gameBoard[i][j].isMine){
                    boards["config"].gameBoard[i][j].Tile.setTexture(textureManager::getTexture("mine"));
                    window.draw(boards["config"].gameBoard[i][j].Tile);
                }
            }
            else {
                boards["config"].gameBoard[i][j].Tile.setTexture(textureManager::getTexture("tile_hidden"));
                window.draw(boards["config"].gameBoard[i][j].Tile);
            }
            if(boards["config"].gameBoard[i][j].isFlag) {
                boards["config"].gameBoard[i][j].Tile.setTexture(textureManager::getTexture("flag"));
                window.draw(boards["config"].gameBoard[i][j].Tile);
            }
            if(boards["config"].debugMode && boards["config"].gameBoard[i][j].isMine){
                boards["config"].gameBoard[i][j].Tile.setTexture(textureManager::getTexture("mine"));
                window.draw(boards["config"].gameBoard[i][j].Tile);
            }
            if(boards["config"].won && boards["config"].gameBoard[i][j].isMine){
                boards["config"].gameBoard[i][j].Tile.setTexture(textureManager::getTexture("tile_hidden"));
                window.draw(boards["config"].gameBoard[i][j].Tile);
                boards["config"].gameBoard[i][j].Tile.setTexture(textureManager::getTexture("flag"));
                window.draw(boards["config"].gameBoard[i][j].Tile);
            }

        }
    }
}
void board::read(std::string filename){
    string s;
    bool temp;
    won = false;
    lost = false;
    gameOver = false;
    ifstream file(filename);
    int i = 0;
    if(file.is_open() ){
        int numMinesTemp = 0;
        while(getline(file, s)) {
            for (int j = 0; j < s.size(); j++) {
                if (s.at(j) == '1') {
                    gameBoard[i][j].isMine = true;
                    numMinesTemp++;
                }
            }
            i++;
        }
        numMines = numMinesTemp;
    }
    sideTileCheck();
}
void board::resetBoard(string test, map<string, board>& boards){
    boards["config"].debugMode = false;
    boards["config"].gameOver = false;
    boards["config"].won = false;
    boards["config"].lost = false;
    boards["config"].flagCounter = 0;
    for(int i =0; i < numRows; i++){
        for(int j = 0; j < numCol; j++){
            boards["config"].gameBoard[i][j].isMine = false;
            boards["config"].gameBoard[i][j].isFlag = false;
            boards["config"].gameBoard[i][j].isReveal = false;
            boards["config"].gameBoard[i][j].makeMine(false);
        }
    }
    if(test == "config"){
        fstream file("boards/config.cfg");
        int numMinesTemp = 0;
        file >> numMinesTemp >> numMinesTemp  >> numMinesTemp;
        numMines = numMinesTemp;
        file.close();
    }
    if(test == "Test1"){
        for(int i =0; i < numRows; i++){
            for(int j = 0; j < numCol; j++){
                boards["config"].gameBoard[i][j].isMine = false;
                boards["config"].gameBoard[i][j].isFlag = false;
                boards["config"].gameBoard[i][j].isReveal = false;
                boards["config"].gameBoard[i][j].makeMine(false);
            }
        }
        read("boards/testboard1.brd");
    }
    else if(test == "Test2"){
        for(int i =0; i < numRows; i++){
            for(int j = 0; j < numCol; j++){
                boards["config"].gameBoard[i][j].isMine = false;
                boards["config"].gameBoard[i][j].isFlag = false;
                boards["config"].gameBoard[i][j].isReveal = false;
                boards["config"].gameBoard[i][j].makeMine(false);
            }
        }
        read("boards/testboard2.brd");
    }
    else if(test == "Test3"){
        for(int i =0; i < numRows; i++){
            for(int j = 0; j < numCol; j++){
                boards["config"].gameBoard[i][j].isMine = false;
                boards["config"].gameBoard[i][j].isFlag = false;
                boards["config"].gameBoard[i][j].isReveal = false;
                boards["config"].gameBoard[i][j].makeMine(false);
            }
        }
        read("boards/testboard3.brd");
    }
}
void board::gameCheck() {
    for(int i = 0; i < gameBoard.size(); i++){
        for(int j = 0; j < gameBoard[i].size(); j++){
            if(!gameBoard[i][j].isMine && !gameBoard[i][j].isReveal){
                return;
            }
        }
    }
    flagCounter = numMines;
    won = true;
    lost = true;
    gameOver = true;
}
void board::gameEnd() {
    for(int i = 0; i < gameBoard.size(); i++){
        for(int j = 0; j < gameBoard[i].size(); j++){
            if(gameBoard[i][j].isMine){
                gameBoard[i][j].isReveal = true;
            }

        }
    }
    //disable clicks right here

    //change smile face to lose face this line
    gameOver = true;

}

