#include <map>
#include <string>
#include <SFML/Graphics.hpp>

using namespace std;
using namespace sf;



struct textureManager {
    //this is store the images
    //texture is just an image
    static map<string, Texture> textures;

    static void loadTexture(string file);
    static Texture& getTexture(string file);




};


