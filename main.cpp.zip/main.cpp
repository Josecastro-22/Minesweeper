#include "Board.h"

int main()
{
    cout << "running" << endl;
    sf::Sprite debugSprite(textureManager::getTexture("debug"));
    sf::Sprite digitsSprite(textureManager::getTexture("digits"));
    sf::Sprite faceHappySprite(textureManager::getTexture("face_happy"));
    sf::Sprite faceLoseSprite(textureManager::getTexture("face_lose"));
    sf::Sprite faceWinSprite(textureManager::getTexture("face_win"));
    sf::Sprite flagSprite(textureManager::getTexture("flag"));
    sf::Sprite mineSprite(textureManager::getTexture("mine"));
    sf::Sprite num1Sprite(textureManager::getTexture("number_1"));
    sf::Sprite num2Sprite(textureManager::getTexture("number_2"));
    sf::Sprite num3Sprite(textureManager::getTexture("number_3"));
    sf::Sprite num4Sprite(textureManager::getTexture("number_4"));
    sf::Sprite num5Sprite(textureManager::getTexture("number_5"));
    sf::Sprite num6Sprite(textureManager::getTexture("number_6"));
    sf::Sprite num7Sprite(textureManager::getTexture("number_7"));
    sf::Sprite num8Sprite(textureManager::getTexture("number_8"));
    sf::Sprite test1Sprite(textureManager::getTexture("test_1"));
    sf::Sprite test2Sprite(textureManager::getTexture("test_2"));
    sf::Sprite test3Sprite(textureManager::getTexture("test_3"));
    sf::Sprite tileHiddenSprite(textureManager::getTexture("tile_hidden"));
    sf::Sprite tileRevealedSprite(textureManager::getTexture("tile_revealed"));
    map<string, board> boards;
    cout << "before reading" << endl;
    readIn(boards);
    cout << "after reading" << endl;
    int width = boards["config"].numCol * 32;
    int height = boards["config"].numRows * 32 + 100;
    cout << "running" << endl;
    sf::RenderWindow window(sf::VideoMode(width, height),"Minesweeper" );
    faceHappySprite.setPosition(sf::Vector2f(window.getSize().x/2, window.getSize().y - 88));
    debugSprite.setPosition(sf::Vector2f(faceHappySprite.getPosition().x + faceHappySprite.getTextureRect().width * 2,  window.getSize().y - 88));
    faceLoseSprite.setPosition(sf::Vector2f(window.getSize().x/2, window.getSize().y - 88));
    test1Sprite.setPosition(sf::Vector2f(debugSprite.getPosition().x + debugSprite.getTextureRect().width + 2, window.getSize().y - 88));
    test2Sprite.setPosition(sf::Vector2f(test1Sprite.getPosition().x + test1Sprite.getTextureRect().width + 2, window.getSize().y - 88));
    test3Sprite.setPosition(sf::Vector2f(test2Sprite.getPosition().x + test2Sprite.getTextureRect().width + 2, window.getSize().y - 88));
    faceWinSprite.setPosition(sf::Vector2f(window.getSize().x/2, window.getSize().y - 88));


    while (window.isOpen()){
        sf::Vector2i mCoordinates = sf::Mouse::getPosition(window);
        sf::Event event;
        while(window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
            if (event.type == sf::Event::MouseButtonPressed) {
                auto coordinates = sf::Mouse::getPosition(window);
                if (event.mouseButton.button == sf::Mouse::Left) {
                    for (int i = 0; i < boards["config"].numRows; i++) {
                        for (int j = 0; j < boards["config"].numCol; j++) {
                            if(!boards["config"].gameOver && boards["config"].gameBoard[i][j].Tile.getGlobalBounds().contains(coordinates.x,coordinates.y)) {
                                if(!boards["config"].gameBoard[i][j].isFlag){
                                    boards["config"].recursion(i, j);
                                    boards["config"].gameCheck();
                                    boards["config"].gameBoard[i][j].isReveal = true;
                                    if(boards["config"].gameBoard[i][j].isMine){
                                        boards["config"].gameEnd();
                                    }
                                }
                                break;
                            }
                        }
                        //boards["config"].gameCheck();
                    }
                    if(debugSprite.getGlobalBounds().contains(coordinates.x,coordinates.y)) {
                        boards["config"].debugMode = !boards["config"].debugMode;
                    }
                    if(test1Sprite.getGlobalBounds().contains(coordinates.x,coordinates.y)){
                        boards["config"].resetBoard("Test1", boards );
                    }
                    if(test2Sprite.getGlobalBounds().contains(coordinates.x,coordinates.y)){
                        boards["config"].resetBoard("Test2", boards );
                    }
                    if(test3Sprite.getGlobalBounds().contains(coordinates.x,coordinates.y)){
                        boards["config"].resetBoard("Test3", boards );
                    }
                    if(!boards["config"].gameOver && faceHappySprite.getGlobalBounds().contains(coordinates.x, coordinates.y)){
                        //make sure you reset everything
                        boards["config"].gameOver = false;
                        boards["config"].lost = false;
                        boards["config"].won = false;
                        //boards["config"].gameBoard.clear();
                        cout << "happy face clicked" << endl;
                        for (int i = 0; i < boards["config"].numRows; i++) {
                            for (int j = 0; j < boards["config"].numCol; j++) {
                                boards["config"].gameBoard[i][j].isMine = false;
                                boards["config"].gameBoard[i][j].isFlag = false;
                            }
                        }
                        boards["config"].resetBoard("config", boards);
                        boards["config"].getRandomMines();
                    }
                    else if(boards["config"].gameOver && faceLoseSprite.getGlobalBounds().contains(coordinates.x, coordinates.y)){
                        //reset
                        boards["config"].resetBoard("test", boards);
                        //draw face happy
                        faceHappySprite.setPosition(sf::Vector2f(window.getSize().x/2, window.getSize().y - 88));
                        window.draw(faceHappySprite);
                        debugSprite.setPosition(sf::Vector2f(faceHappySprite.getPosition().x + faceHappySprite.getTextureRect().width * 2,  window.getSize().y - 88));
                    }
                }
                if (event.mouseButton.button == sf::Mouse::Right) {
                    for (int i = 0; i < boards["config"].numRows; i++) {
                        for (int j = 0; j < boards["config"].numCol; j++) {
                            if(!boards["config"].gameOver && boards["config"].gameBoard[i][j].Tile.getGlobalBounds().contains(coordinates.x,coordinates.y)) {
                                boards["config"].gameBoard[i][j].isFlag = !boards["config"].gameBoard[i][j].isFlag;
                                if(boards["config"].gameBoard[i][j].isFlag)
                                    boards["config"].flagCounter++;
                                else
                                    boards["config"].flagCounter--;
                            }
                        }
                    }
                }
            }
            window.clear();
            if (boards["config"].lost == true) {
                window.draw(faceLoseSprite);
            }
            if(boards["config"].won == true){
                window.draw(faceWinSprite);
            }
        }
        draw(window, boards);
        boards["config"].remainingMines(window, width, height);

        if(!boards["config"].gameOver){
            window.draw(faceHappySprite);
        }
        else {
            window.draw(faceLoseSprite);
        }
        if(boards["config"].won){
            window.draw(faceWinSprite);
        }
        window.draw(debugSprite);
        window.draw(test1Sprite);
        window.draw(test2Sprite);
        window.draw(test3Sprite);
        window.display();
    }
}
